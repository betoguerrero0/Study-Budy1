/**
 * studyBuddy - Gamification Engine & Productivity Core
 * Producto Final de Producción
 * Incluye: Temporizador Pomodoro Pro, Mascota Dragón Multietapa, Sintetizador Web Audio,
 * Calendario de Rachas, Misiones Diarias, Tienda de Auras/Hábitats, Tareas y Estadísticas.
 */

// ==========================================
// 1. ESTADO GLOBAL Y PERSISTENCIA
// ==========================================

const DEFAULT_STATE = {
  // Rachas y Metas
  streak: 1,
  bestStreak: 1,
  goalDays: 7, // 7, 21, 30, 60, 100
  totalMinutes: 45,
  totalSessions: 3,
  lastSessionDate: null,
  streakFreezes: 1, // Escudos protectores de racha
  completedDates: [],

  // Mascota Dragón
  dragonBond: 35, // 0 - 100
  dragonEnergy: 90, // 0 - 100
  dragonAura: 'crimson', // crimson, astral, golden, emerald, frost
  dragonHabitat: 'volcano', // volcano, astral, forest, crystal
  dragonLevel: 1,
  dragonXp: 120,
  dragonCoins: 150,

  // Personalización y Desbloqueos
  unlockedAuras: ['crimson', 'astral'],
  unlockedHabitats: ['volcano'],
  unlockedBadges: ['first_step'],

  // Configuración de Sesión & Temporizador
  activeDurationMinutes: 25,
  timerMode: 'pomodoro', // pomodoro, deepwork, quick, ultra, custom, shortbreak
  selectedSubject: 'General',
  theme: 'default', // default, astral, cyberpunk, light
  soundEnabled: true,
  soundVolume: 0.7,

  // Tareas de Estudio
  tasks: [
    { id: 't_1', text: 'Repasar conceptos clave de la lección', completed: false, subject: 'General' },
    { id: 't_2', text: 'Resolver 3 ejercicios de práctica', completed: false, subject: 'General' }
  ],

  // Misiones Diarias
  dailyQuests: [
    { id: 'q_1', title: 'Realiza 1 sesión de estudio', target: 1, current: 0, rewardCoins: 30, rewardXp: 50, claimed: false },
    { id: 'q_2', title: 'Acaricia y cuida a tu Dragón', target: 1, current: 0, rewardCoins: 20, rewardXp: 30, claimed: false },
    { id: 'q_3', title: 'Completa al menos 1 tarea de estudio', target: 1, current: 0, rewardCoins: 25, rewardXp: 40, claimed: false }
  ],

  // Registro Histórico de Sesiones
  sessionLogs: []
};

let appState = loadState();

function loadState() {
  try {
    const saved = localStorage.getItem('studyBuddy_pro_v2_state');
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...DEFAULT_STATE, ...parsed };
    }
  } catch (e) {
    console.error('Error al cargar estado de localStorage:', e);
  }
  // Fecha de hoy por defecto para empezar con buena experiencia
  const today = getTodayISO();
  const initial = { ...DEFAULT_STATE };
  initial.completedDates = [today];
  initial.lastSessionDate = today;
  return initial;
}

function saveState() {
  try {
    localStorage.setItem('studyBuddy_pro_v2_state', JSON.stringify(appState));
  } catch (e) {
    console.error('Error al guardar estado:', e);
  }
}

function getTodayISO() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// ==========================================
// 2. ETAPAS DEL DRAGÓN (4 ETAPAS COMPLETAS)
// ==========================================

const DRAGON_STAGES = [
  {
    id: 0,
    name: "Huevo Sagrado",
    subtitle: "Huevo Cósmico de Fuego y Luz",
    minStreak: 0,
    nextThreshold: 3,
    dialogue: [
      "El huevo irradia una suave calidez... Siente tu dedicación.",
      "Un pequeño destello recorre el cascarón cuando abres tus libros.",
      "¡Sigue estudiando! Muy pronto romperá el cascarón estelar."
    ],
    svg: `
      <svg class="dragon-svg-body" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="eggGrad" cx="38%" cy="32%" r="65%">
            <stop offset="0%" stop-color="#FFE082"/>
            <stop offset="35%" stop-color="#FF7043"/>
            <stop offset="80%" stop-color="#D84315"/>
            <stop offset="100%" stop-color="#2D120B"/>
          </radialGradient>
          <filter id="eggGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="5" result="blur"/>
            <feComposite in="SourceGraphic" in2="blur" operator="over"/>
          </filter>
        </defs>
        <!-- Nido de brasas y runas -->
        <ellipse cx="100" cy="165" rx="65" ry="16" fill="#1A1210" opacity="0.8"/>
        <path d="M40 165 Q100 185 160 165 Q100 152 40 165 Z" fill="#D84315" opacity="0.9"/>
        <circle cx="65" cy="162" r="5" fill="#FFB300"/>
        <circle cx="135" cy="164" r="5" fill="#FF7043"/>
        <circle cx="100" cy="167" r="4" fill="#FFEB3B"/>
        <!-- Silueta del huevo -->
        <path d="M100 30 C145 30 165 95 160 145 C155 175 125 178 100 178 C75 178 45 175 40 145 C35 95 55 30 100 30 Z"
              fill="url(#eggGrad)" filter="url(#eggGlow)"/>
        <!-- Escamas doradas -->
        <path d="M85 80 Q100 95 115 80" stroke="#FFE082" stroke-width="3" fill="none" opacity="0.7"/>
        <path d="M75 105 Q100 125 125 105" stroke="#FFE082" stroke-width="3" fill="none" opacity="0.6"/>
        <path d="M80 130 Q100 148 120 130" stroke="#FFE082" stroke-width="2.5" fill="none" opacity="0.5"/>
        <!-- Grietas de energía viva -->
        <path d="M100 65 L95 85 L108 100 L102 118" stroke="#FFF9C4" stroke-width="3.5" stroke-linecap="round" fill="none"/>
        <ellipse cx="85" cy="70" rx="14" ry="24" fill="#FFFFFF" opacity="0.3" transform="rotate(-18 85 70)"/>
      </svg>
    `
  },
  {
    id: 1,
    name: "Cría Ignis",
    subtitle: "Pequeño Dragón Ígneo",
    minStreak: 3,
    nextThreshold: 7,
    dialogue: [
      "¡Piiiu! *estornuda una chispita dorada* ¡Vamos a estudiar más!",
      "Ignis bate sus alitas con emoción cada vez que avanzas en tus metas.",
      "¡Mira cuánto hemos crecido en tan solo unos días de hábito!"
    ],
    svg: `
      <svg class="dragon-svg-body" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="ignisBody" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FF8A65"/>
            <stop offset="55%" stop-color="#FF5722"/>
            <stop offset="100%" stop-color="#D84315"/>
          </linearGradient>
          <linearGradient id="ignisBelly" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#FFF9C4"/>
            <stop offset="100%" stop-color="#FFE082"/>
          </linearGradient>
        </defs>
        <!-- Cola con fueguito -->
        <path d="M135 145 Q165 140 170 120 Q175 105 162 108" fill="none" stroke="#FF5722" stroke-width="12" stroke-linecap="round"/>
        <path d="M165 105 C175 90 185 110 170 118 Z" fill="#FFC107"/>
        <circle cx="168" cy="108" r="4" fill="#FFF59D"/>
        <!-- Alas chiquitas -->
        <path d="M60 115 Q30 90 45 75 Q65 85 75 110 Z" fill="#E64A19"/>
        <path d="M135 115 Q165 90 150 75 Q130 85 120 110 Z" fill="#E64A19"/>
        <!-- Patitas traseras -->
        <ellipse cx="68" cy="162" rx="16" ry="10" fill="#BF360C"/>
        <ellipse cx="132" cy="162" rx="16" ry="10" fill="#BF360C"/>
        <!-- Cuerpo gordito -->
        <ellipse cx="100" cy="135" rx="42" ry="38" fill="url(#ignisBody)"/>
        <!-- Pancita -->
        <ellipse cx="100" cy="142" rx="26" ry="24" fill="url(#ignisBelly)"/>
        <!-- Patitas delanteras -->
        <circle cx="85" cy="145" r="7" fill="#FF8A65"/>
        <circle cx="115" cy="145" r="7" fill="#FF8A65"/>
        <!-- Cabeza tierna -->
        <circle cx="100" cy="78" r="35" fill="url(#ignisBody)"/>
        <!-- Cuernitos suaves -->
        <path d="M78 52 Q72 32 84 38 Q88 46 86 54 Z" fill="#FFB74D"/>
        <path d="M122 52 Q128 32 116 38 Q112 46 114 54 Z" fill="#FFB74D"/>
        <!-- Mejillas sonrojadas -->
        <circle cx="75" cy="85" r="7" fill="#FF3D00" opacity="0.45"/>
        <circle cx="125" cy="85" r="7" fill="#FF3D00" opacity="0.45"/>
        <!-- Ojos brillantes -->
        <ellipse cx="85" cy="74" rx="8" ry="11" fill="#18181B"/>
        <circle cx="82" cy="70" r="3.5" fill="#FFFFFF"/>
        <circle cx="87" cy="78" r="1.5" fill="#FFFFFF"/>
        <ellipse cx="115" cy="74" rx="8" ry="11" fill="#18181B"/>
        <circle cx="112" cy="70" r="3.5" fill="#FFFFFF"/>
        <circle cx="117" cy="78" r="1.5" fill="#FFFFFF"/>
        <!-- Sonrisa feliz -->
        <path d="M94 88 Q100 95 106 88" stroke="#BF360C" stroke-width="2.5" stroke-linecap="round" fill="none"/>
      </svg>
    `
  },
  {
    id: 2,
    name: "Dragón Pyro",
    subtitle: "Dragón Guardián de Fuego",
    minStreak: 7,
    nextThreshold: 21,
    dialogue: [
      "¡Una semana de racha o más! Nuestras alas cortan cualquier distracción.",
      "El fuego de la disciplina arde con firmeza. ¡Hoy sumaremos otra victoria!",
      "Mi aliento ardiente protegerá tu concentración de cualquier pereza."
    ],
    svg: `
      <svg class="dragon-svg-body" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="pyroRed" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FF5722"/>
            <stop offset="60%" stop-color="#E64A19"/>
            <stop offset="100%" stop-color="#BF360C"/>
          </linearGradient>
          <linearGradient id="wingFire" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FFB300"/>
            <stop offset="100%" stop-color="#FF3D00"/>
          </linearGradient>
        </defs>
        <!-- Alas imponentes extendidas -->
        <path d="M45 110 Q5 60 30 30 Q65 60 70 100 Z" fill="url(#wingFire)" opacity="0.95"/>
        <path d="M155 110 Q195 60 170 30 Q135 60 130 100 Z" fill="url(#wingFire)" opacity="0.95"/>
        <!-- Huesos de las alas -->
        <path d="M30 30 Q50 65 72 102" stroke="#BF360C" stroke-width="3" fill="none"/>
        <path d="M170 30 Q150 65 128 102" stroke="#BF360C" stroke-width="3" fill="none"/>
        <!-- Cola con púa de fuego -->
        <path d="M130 150 Q175 160 185 130 Q180 115 160 120" fill="none" stroke="url(#pyroRed)" stroke-width="14" stroke-linecap="round"/>
        <path d="M178 120 L195 110 L190 135 Z" fill="#FFC107"/>
        <!-- Cuerpo fuerte -->
        <path d="M70 120 Q60 165 100 170 Q140 165 130 120 Q120 95 100 95 Q80 95 70 120 Z" fill="url(#pyroRed)"/>
        <!-- Pecho de magma segmentado -->
        <path d="M85 118 Q100 125 115 118 Q118 135 100 145 Q82 135 85 118 Z" fill="#FFE082"/>
        <path d="M88 145 Q100 152 112 145 Q110 160 100 165 Q90 160 88 145 Z" fill="#FFB74D"/>
        <!-- Garras y patas -->
        <path d="M60 160 Q55 175 75 175 Q85 175 80 160 Z" fill="#870000"/>
        <path d="M140 160 Q145 175 125 175 Q115 175 120 160 Z" fill="#870000"/>
        <!-- Cabeza majestuosa -->
        <path d="M75 60 Q100 45 125 60 Q130 85 100 95 Q70 85 75 60 Z" fill="url(#pyroRed)"/>
        <!-- Cuernos afilados -->
        <path d="M76 56 Q55 30 70 20 Q82 35 82 52 Z" fill="#FFC107"/>
        <path d="M124 56 Q145 30 130 20 Q118 35 118 52 Z" fill="#FFC107"/>
        <!-- Ojos intensos -->
        <polygon points="82,65 94,62 90,70" fill="#FFEB3B"/>
        <polygon points="118,65 106,62 110,70" fill="#FFEB3B"/>
        <circle cx="87" cy="65" r="2.5" fill="#18181B"/>
        <circle cx="113" cy="65" r="2.5" fill="#18181B"/>
      </svg>
    `
  },
  {
    id: 3,
    name: "Draconis Ancestral",
    subtitle: "Dragón Astral Legendario del Conocimiento",
    minStreak: 21,
    nextThreshold: null,
    dialogue: [
      "¡Has forjado la maestría absoluta! El cosmos se inclina ante tu constancia.",
      "Tu hábito de estudio es ahora una fortaleza inquebrantable.",
      "La llama estelar de Draconis iluminará todos tus proyectos y exámenes."
    ],
    svg: `
      <svg class="dragon-svg-body" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="astralHalo" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#FFD700" stop-opacity="0.85"/>
            <stop offset="60%" stop-color="#7C4DFF" stop-opacity="0.45"/>
            <stop offset="100%" stop-color="#000000" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="astralBody" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FF9800"/>
            <stop offset="50%" stop-color="#E040FB"/>
            <stop offset="100%" stop-color="#311B92"/>
          </linearGradient>
          <linearGradient id="wingGold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#FFE082"/>
            <stop offset="50%" stop-color="#FF6F00"/>
            <stop offset="100%" stop-color="#4A148C"/>
          </linearGradient>
        </defs>
        <!-- Halo cósmico divino -->
        <circle cx="100" cy="90" r="88" fill="url(#astralHalo)"/>
        <!-- Corona astral flotante -->
        <path d="M80 20 L90 32 L100 12 L110 32 L120 20 L115 38 L85 38 Z" fill="#FFD700" stroke="#FFF9C4" stroke-width="1.5"/>
        <!-- Alas colosales con constelaciones -->
        <path d="M40 105 Q-10 40 25 15 Q65 45 75 95 Z" fill="url(#wingGold)"/>
        <path d="M160 105 Q210 40 175 15 Q135 45 125 95 Z" fill="url(#wingGold)"/>
        <circle cx="28" cy="45" r="2.5" fill="#FFFFFF"/>
        <circle cx="45" cy="30" r="2" fill="#FFF59D"/>
        <circle cx="172" cy="45" r="2.5" fill="#FFFFFF"/>
        <circle cx="155" cy="30" r="2" fill="#FFF59D"/>
        <!-- Cola majestuosa -->
        <path d="M125 145 Q180 170 185 125 Q180 95 160 105" fill="none" stroke="url(#astralBody)" stroke-width="15" stroke-linecap="round"/>
        <circle cx="180" cy="115" r="8" fill="#FFD700"/>
        <circle cx="180" cy="115" r="4" fill="#FFFFFF"/>
        <!-- Cuerpo legendario -->
        <path d="M68 115 Q55 165 100 172 Q145 165 132 115 Q120 90 100 90 Q80 90 68 115 Z" fill="url(#astralBody)"/>
        <!-- Placa pectoral resplandeciente -->
        <path d="M82 115 Q100 125 118 115 Q120 140 100 155 Q80 140 82 115 Z" fill="#FFE082" stroke="#FFF" stroke-width="1"/>
        <polygon points="100,126 104,136 100,146 96,136" fill="#7C4DFF"/>
        <!-- Cabeza noble -->
        <path d="M72 56 Q100 40 128 56 Q134 85 100 96 Q66 85 72 56 Z" fill="url(#astralBody)"/>
        <!-- Cuernos sagrados dorados -->
        <path d="M75 50 Q45 15 62 10 Q78 28 80 48 Z" fill="#FFD700"/>
        <path d="M125 50 Q155 15 138 10 Q122 28 120 48 Z" fill="#FFD700"/>
        <!-- Ojos galácticos -->
        <ellipse cx="86" cy="65" rx="5" ry="3" fill="#FFFFFF"/>
        <ellipse cx="114" cy="65" rx="5" ry="3" fill="#FFFFFF"/>
        <circle cx="86" cy="65" r="2.5" fill="#7C4DFF"/>
        <circle cx="114" cy="65" r="2.5" fill="#7C4DFF"/>
      </svg>
    `
  }
];

function getDragonStageByStreak(streakDays) {
  if (streakDays >= 21) return DRAGON_STAGES[3];
  if (streakDays >= 7) return DRAGON_STAGES[2];
  if (streakDays >= 3) return DRAGON_STAGES[1];
  return DRAGON_STAGES[0];
}

// ==========================================
// 3. SINTETIZADOR DE AUDIO (Web Audio API)
// ==========================================

class AudioSynthEngine {
  constructor() {
    this.ctx = null;
    this.ambientNodes = null;
    this.currentAmbient = 'none';
    this.enabled = true;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleSound() {
    this.enabled = !this.enabled;
    appState.soundEnabled = this.enabled;
    if (!this.enabled) {
      this.stopAmbient();
    }
    saveState();
    return this.enabled;
  }

  playClick() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(680, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.035);

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.045);
    } catch (e) {}
  }

  playHover() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1100, now + 0.02);

      gain.gain.setValueAtTime(0.015, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.03);
    } catch (e) {}
  }

  playSessionStart() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const chords = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      chords.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0.001, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.45);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.5);
      });
    } catch (e) {}
  }

  playVictoryFanfare() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const notes = [
        { f: 523.25, d: 0.12 },
        { f: 659.25, d: 0.12 },
        { f: 783.99, d: 0.14 },
        { f: 1046.50, d: 0.35 },
        { f: 880.00, d: 0.14 },
        { f: 1046.50, d: 0.65 }
      ];

      let t = now;
      notes.forEach((n) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(n.f, t);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.25, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + n.d);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(t);
        osc.stop(t + n.d + 0.05);
        t += n.d * 0.88;
      });
    } catch (e) {}
  }

  playDragonAction(stageId) {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;

      if (stageId === 0) {
        // Huevo cósmico
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(580, now + 0.25);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (stageId === 1) {
        // Cría Ignis
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(620, now);
        osc.frequency.exponentialRampToValueAtTime(950, now + 0.12);
        osc.frequency.exponentialRampToValueAtTime(520, now + 0.28);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else {
        // Pyro / Draconis: rugido
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(140, now);
        osc1.frequency.exponentialRampToValueAtTime(70, now + 0.55);

        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(220, now);
        osc2.frequency.exponentialRampToValueAtTime(100, now + 0.55);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.28, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(this.ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.7);
        osc2.stop(now + 0.7);
      }
    } catch (e) {}
  }

  playRoarBreath() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;

      const bufferSize = this.ctx.sampleRate * 0.85;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(320, now);
      filter.frequency.exponentialRampToValueAtTime(900, now + 0.35);
      filter.frequency.exponentialRampToValueAtTime(220, now + 0.8);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.3, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.85);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + 0.9);
    } catch (e) {}
  }

  playChimeTreasure() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const arpeggio = [659.25, 783.99, 987.77, 1318.51, 1567.98];
      arpeggio.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.06);

        gain.gain.setValueAtTime(0.001, now + idx * 0.06);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.06 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.06 + 0.35);

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + idx * 0.06);
        osc.stop(now + idx * 0.06 + 0.4);
      });
    } catch (e) {}
  }

  // Generador de Paisajes Sonoros Procedurales
  setAmbient(type) {
    this.stopAmbient();
    this.currentAmbient = type;
    if (type === 'none' || !this.enabled) return;

    try {
      this.init();
      if (!this.ctx) return;

      const bufferSize = this.ctx.sampleRate * 2.5;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      if (type === 'rain') {
        filter.type = 'lowpass';
        filter.frequency.value = 750;
        gain.gain.value = 0.07;
      } else if (type === 'fire') {
        filter.type = 'bandpass';
        filter.frequency.value = 400;
        filter.Q.value = 2.5;
        gain.gain.value = 0.1;
      } else if (type === 'lofi') {
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.value = 174;
        filter.type = 'lowpass';
        filter.frequency.value = 320;
        gain.gain.value = 0.06;

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        this.ambientNodes = { osc, gain };
        return;
      } else if (type === 'space') {
        const osc = this.ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.value = 108;
        filter.type = 'lowpass';
        filter.frequency.value = 240;
        gain.gain.value = 0.08;

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        this.ambientNodes = { osc, gain };
        return;
      }

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      whiteNoise.start();

      this.ambientNodes = { whiteNoise, gain };
    } catch (e) {
      console.warn('Error en generador ambiental:', e);
    }
  }

  stopAmbient() {
    if (this.ambientNodes) {
      try {
        if (this.ambientNodes.whiteNoise) this.ambientNodes.whiteNoise.stop();
        if (this.ambientNodes.osc) this.ambientNodes.osc.stop();
      } catch (e) {}
      this.ambientNodes = null;
    }
  }
}

const audioSynth = new AudioSynthEngine();

// ==========================================
// 4. MOTOR DEL TEMPORIZADOR POMODORO PRO
// ==========================================

class StudyTimerEngine {
  constructor() {
    this.totalSeconds = 25 * 60;
    this.remainingSeconds = 25 * 60;
    this.intervalId = null;
    this.isRunning = false;
    this.isPaused = false;
    this.isBreak = false;
    this.ringCircumference = 2 * Math.PI * 115; // 722.56
  }

  setDuration(minutes) {
    if (this.isRunning) return;
    appState.activeDurationMinutes = minutes;
    this.totalSeconds = minutes * 60;
    this.remainingSeconds = this.totalSeconds;
    this.isBreak = false;
    this.updateDisplay();
    this.updateProgressRing(0);
    saveState();
  }

  start() {
    if (this.isRunning && !this.isPaused) return;

    audioSynth.playSessionStart();
    this.isRunning = true;
    this.isPaused = false;

    this.updateControlButtons();
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => this.tick(), 1000);

    const statusEl = document.getElementById('session-status-text');
    if (statusEl) {
      statusEl.textContent = this.isBreak ? "Descanso merecido 🍃" : "Sesión de Enfoque Activa 🔥";
      statusEl.style.color = this.isBreak ? "var(--magic-emerald)" : "var(--accent-orange)";
    }
  }

  pause() {
    if (!this.isRunning || this.isPaused) return;
    this.isPaused = true;
    clearInterval(this.intervalId);

    const statusEl = document.getElementById('session-status-text');
    if (statusEl) {
      statusEl.textContent = "Sesión en pausa ⏸️";
      statusEl.style.color = "var(--accent-gold)";
    }

    const btnPauseText = document.getElementById('btn-pause-text');
    if (btnPauseText) btnPauseText.textContent = "Reanudar";
  }

  resume() {
    if (!this.isRunning || !this.isPaused) return;
    this.isPaused = false;
    this.intervalId = setInterval(() => this.tick(), 1000);

    const statusEl = document.getElementById('session-status-text');
    if (statusEl) {
      statusEl.textContent = "Sesión de Enfoque Activa 🔥";
      statusEl.style.color = "var(--accent-orange)";
    }

    const btnPauseText = document.getElementById('btn-pause-text');
    if (btnPauseText) btnPauseText.textContent = "Pausar";
  }

  reset() {
    clearInterval(this.intervalId);
    this.isRunning = false;
    this.isPaused = false;
    this.remainingSeconds = this.totalSeconds;
    this.updateDisplay();
    this.updateProgressRing(0);
    this.updateControlButtons();

    const statusEl = document.getElementById('session-status-text');
    if (statusEl) {
      statusEl.textContent = "Listo para comenzar";
      statusEl.style.color = "var(--text-muted)";
    }

    document.title = "studyBuddy | Enfoque, Hábitos & Dragón";
  }

  tick() {
    if (this.remainingSeconds > 0) {
      this.remainingSeconds--;
      this.updateDisplay();
      const progress = 1 - (this.remainingSeconds / this.totalSeconds);
      this.updateProgressRing(progress);
    } else {
      this.completeSession();
    }
  }

  updateDisplay() {
    const mins = Math.floor(this.remainingSeconds / 60);
    const secs = this.remainingSeconds % 60;
    const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

    const timerDigits = document.getElementById('timer-digits');
    if (timerDigits) timerDigits.textContent = formatted;

    const focusGiant = document.getElementById('focus-timer-giant');
    if (focusGiant) focusGiant.textContent = formatted;

    if (this.isRunning) {
      document.title = `(${formatted}) ${this.isBreak ? 'Descanso' : 'Estudiando'} | studyBuddy`;
    }
  }

  updateProgressRing(percent) {
    const ring = document.getElementById('timer-progress-ring');
    if (!ring) return;
    const offset = this.ringCircumference - (percent * this.ringCircumference);
    ring.style.strokeDashoffset = offset;
  }

  updateControlButtons() {
    const btnStart = document.getElementById('btn-start-timer');
    const btnPause = document.getElementById('btn-pause-timer');
    const btnReset = document.getElementById('btn-reset-timer');

    if (this.isRunning) {
      if (btnStart) btnStart.style.display = 'none';
      if (btnPause) btnPause.style.display = 'inline-flex';
      if (btnReset) btnReset.style.display = 'inline-flex';
      const btnPauseText = document.getElementById('btn-pause-text');
      if (btnPauseText) btnPauseText.textContent = this.isPaused ? "Reanudar" : "Pausar";
    } else {
      if (btnStart) btnStart.style.display = 'inline-flex';
      if (btnPause) btnPause.style.display = 'none';
      if (btnReset) btnReset.style.display = 'none';
    }
  }

  completeSession() {
    clearInterval(this.intervalId);
    this.isRunning = false;
    this.isPaused = false;
    audioSynth.playVictoryFanfare();

    const studiedMins = appState.activeDurationMinutes;

    // Sumar a estadísticas
    appState.totalMinutes += studiedMins;
    appState.totalSessions += 1;

    // Recompensas RPG
    const earnedCoins = Math.round(studiedMins * 1.5) + 10;
    const earnedXp = studiedMins * 4;
    appState.dragonCoins += earnedCoins;
    appState.dragonXp += earnedXp;

    // Subir nivel si procede
    checkDragonLevelUp();

    // Actualizar racha
    const streakResult = registerDailyStreak();

    // Actualizar progreso de misiones diarias
    updateQuestProgress('study', 1);

    // Agregar registro al historial
    appState.sessionLogs.unshift({
      date: new Date().toLocaleString(),
      duration: studiedMins,
      subject: appState.selectedSubject,
      coinsEarned: earnedCoins,
      xpEarned: earnedXp
    });
    if (appState.sessionLogs.length > 50) appState.sessionLogs.pop();

    this.reset();
    renderAllViews();

    // Desplegar celebración
    showCompletionModal(studiedMins, earnedCoins, earnedXp, streakResult);
  }
}

const studyTimer = new StudyTimerEngine();

// ==========================================
// 5. SISTEMA DE RACHAS Y CALENDARIO
// ==========================================

function registerDailyStreak() {
  const today = getTodayISO();
  const prevStage = getDragonStageByStreak(appState.streak);
  let streakIncreased = false;

  if (!appState.completedDates.includes(today)) {
    appState.completedDates.push(today);
  }

  if (appState.lastSessionDate === today) {
    streakIncreased = false;
  } else {
    if (appState.lastSessionDate) {
      const lastDate = new Date(appState.lastSessionDate);
      const currentDate = new Date(today);
      const diffTime = Math.abs(currentDate - lastDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        appState.streak += 1;
        streakIncreased = true;
      } else {
        // ¿Tiene escudo de racha (Streak Freeze)?
        if (appState.streakFreezes > 0 && diffDays === 2) {
          appState.streakFreezes -= 1;
          appState.streak += 1;
          streakIncreased = true;
          showFloatingRPGText('¡Escudo de Racha Usado! 🛡️', '#38bdf8', 150, 100);
        } else {
          appState.streak = 1;
          streakIncreased = true;
        }
      }
    } else {
      appState.streak = 1;
      streakIncreased = true;
    }
  }

  appState.lastSessionDate = today;
  if (appState.streak > appState.bestStreak) {
    appState.bestStreak = appState.streak;
  }

  checkAchievements();
  saveState();

  const newStage = getDragonStageByStreak(appState.streak);
  const evolved = newStage.id > prevStage.id;

  return {
    streakIncreased,
    newStreak: appState.streak,
    evolved,
    newStage
  };
}

// Subida de nivel de la mascota
function checkDragonLevelUp() {
  const neededXp = appState.dragonLevel * 100;
  if (appState.dragonXp >= neededXp) {
    appState.dragonLevel += 1;
    appState.dragonCoins += 50;
    showFloatingRPGText(`¡NIVEL ${appState.dragonLevel} ALCANZADO! 🌟`, '#FFD700', 160, 80);
    audioSynth.playChimeTreasure();
  }
}

// ==========================================
// 6. LOGROS E INSIGNIAS MAESTRAS
// ==========================================

const ALL_ACHIEVEMENTS = [
  { id: 'first_step', name: 'Primer Fuego', icon: '🔥', criteria: 'Completa tu 1ª sesión de estudio', check: (s) => s.totalSessions >= 1 },
  { id: 'streak_3', name: 'Aliento de Chispa', icon: '🐣', criteria: 'Alcanza una racha de 3 días', check: (s) => s.streak >= 3 },
  { id: 'week_master', name: 'Guardián Semanal', icon: '🛡️', criteria: 'Alcanza la meta de 7 días (1 semana)', check: (s) => s.streak >= 7 },
  { id: 'focus_100', name: 'Mente de Diamante', icon: '💎', criteria: 'Acumula 100 minutos estudiados', check: (s) => s.totalMinutes >= 100 },
  { id: 'streak_21', name: 'Hábito de Hierro', icon: '⚔️', criteria: 'Alcanza la meta de 21 días (3 semanas)', check: (s) => s.streak >= 21 },
  { id: 'dragon_legend', name: 'Señor Draconis', icon: '👑', criteria: 'Alcanza la meta de 30 días (1 mes)', check: (s) => s.streak >= 30 },
  { id: 'coin_hoarder', name: 'Tesoro del Dragón', icon: '🪙', criteria: 'Acumula 300 Monedas Dracónicas', check: (s) => s.dragonCoins >= 300 },
  { id: 'task_slayer', name: 'Erudito Implacable', icon: '📜', criteria: 'Completa 5 tareas de estudio', check: (s) => (s.tasksCompletedCount || 0) >= 5 }
];

function checkAchievements() {
  ALL_ACHIEVEMENTS.forEach(ach => {
    if (!appState.unlockedBadges.includes(ach.id) && ach.check(appState)) {
      appState.unlockedBadges.push(ach.id);
      appState.dragonCoins += 40;
      showFloatingRPGText(`¡LOGRO: ${ach.name}! 🏆`, '#F59E0B', 150, 70);
    }
  });
}

function updateQuestProgress(actionType, amount = 1) {
  let changed = false;
  if (actionType === 'study') {
    const q = appState.dailyQuests.find(q => q.id === 'q_1');
    if (q && q.current < q.target) {
      q.current += amount;
      changed = true;
    }
  } else if (actionType === 'pet') {
    const q = appState.dailyQuests.find(q => q.id === 'q_2');
    if (q && q.current < q.target) {
      q.current += amount;
      changed = true;
    }
  } else if (actionType === 'task') {
    const q = appState.dailyQuests.find(q => q.id === 'q_3');
    if (q && q.current < q.target) {
      q.current += amount;
      changed = true;
    }
  }
  if (changed) {
    saveState();
    renderQuests();
  }
}

// ==========================================
// 7. BAZAR DRACÓNICO (CATÁLOGO DE LA TIENDA)
// ==========================================

const SHOP_CATALOG = [
  { id: 'aura_golden', type: 'aura', name: 'Aura Solar Dorada', price: 120, icon: '👑', desc: 'Resplandor divino de gloria y sabiduría.' },
  { id: 'aura_emerald', type: 'aura', name: 'Aura Esmeralda Vital', price: 100, icon: '🍃', desc: 'Energía de serenidad y calma infinita.' },
  { id: 'aura_frost', type: 'aura', name: 'Aura Escarcha Boreal', price: 140, icon: '❄️', desc: 'Frío glacial para mantener la cabeza fría.' },
  { id: 'hab_astral', type: 'habitat', name: 'Templo Astral', price: 200, icon: '🌌', desc: 'Santuario celestial flotando en el cosmos.' },
  { id: 'hab_forest', type: 'habitat', name: 'Bosque Místico', price: 180, icon: '🌲', desc: 'Arboleda de concentración y luciérnagas.' },
  { id: 'hab_crystal', type: 'habitat', name: 'Cueva de Cristal', price: 220, icon: '🔮', desc: 'Caverna profunda llena de gemas puras.' },
  { id: 'item_freeze', type: 'item', name: 'Escudo Protector de Racha', price: 90, icon: '🛡️', desc: 'Protege tu racha si olvidas estudiar un día.' }
];

// ==========================================
// 8. RENDERIZADO VISUAL Y VISTAS
// ==========================================

function renderAllViews() {
  const currentStage = getDragonStageByStreak(appState.streak);

  // 1. Header Global
  const topStreak = document.getElementById('top-streak-count');
  if (topStreak) topStreak.textContent = appState.streak;

  const topCoins = document.getElementById('top-coins-count');
  if (topCoins) topCoins.textContent = appState.dragonCoins;

  const topLevel = document.getElementById('top-level-count');
  if (topLevel) topLevel.textContent = appState.dragonLevel;

  // 2. Banner de Compañero Dragón en Vista Estudio
  const miniFrame = document.getElementById('mini-dragon-avatar-slot');
  if (miniFrame) miniFrame.innerHTML = currentStage.svg;

  const miniName = document.getElementById('mini-dragon-name');
  if (miniName) miniName.textContent = `${currentStage.name} (Nivel ${appState.dragonLevel})`;

  const miniQuote = document.getElementById('dragon-quote');
  if (miniQuote) {
    const q = currentStage.dialogue[Math.floor(Math.random() * currentStage.dialogue.length)];
    miniQuote.textContent = `"${q}"`;
  }

  const miniTag = document.getElementById('mini-dragon-tag');
  if (miniTag) miniTag.textContent = `Etapa ${currentStage.id + 1}: ${currentStage.subtitle}`;

  // 3. Santuario del Dragón Grande
  const sanctuaryBadge = document.getElementById('sanctuary-stage-badge');
  if (sanctuaryBadge) sanctuaryBadge.textContent = `Etapa ${currentStage.id + 1} • ${currentStage.name}`;

  const heroSlot = document.getElementById('dragon-hero-svg-slot');
  if (heroSlot) heroSlot.innerHTML = currentStage.svg;

  const focusSlot = document.getElementById('focus-dragon-companion-slot');
  if (focusSlot) focusSlot.innerHTML = currentStage.svg;

  const speciesTitle = document.getElementById('dragon-species-title');
  if (speciesTitle) speciesTitle.textContent = currentStage.subtitle;

  // Actualizar Aura y Hábitat
  const glowHalo = document.getElementById('dragon-glow-halo');
  if (glowHalo) {
    glowHalo.className = `dragon-glow-halo aura-${appState.dragonAura || 'crimson'}`;
  }

  const habitatStage = document.getElementById('dragon-sanctuary-stage');
  if (habitatStage) {
    habitatStage.className = `dragon-sanctuary-stage stage-habitat-${appState.dragonHabitat || 'volcano'}`;
  }

  // Vínculo y Ánimo
  const bondText = document.getElementById('dragon-bond-level');
  if (bondText) bondText.textContent = `${appState.dragonBond} / 100`;

  const bondFill = document.getElementById('dragon-bond-fill');
  if (bondFill) bondFill.style.width = `${Math.min(100, Math.max(8, appState.dragonBond))}%`;

  const energyText = document.getElementById('dragon-energy-level');
  if (energyText) energyText.textContent = `${appState.dragonEnergy} / 100`;

  const energyFill = document.getElementById('dragon-energy-fill');
  if (energyFill) energyFill.style.width = `${Math.min(100, Math.max(8, appState.dragonEnergy))}%`;

  // Progreso de Evolución
  const ratioText = document.getElementById('evolution-ratio-text');
  const evoFill = document.getElementById('evolution-progress-bar');
  const evoHint = document.getElementById('evolution-hint');

  if (currentStage.nextThreshold) {
    const prevThresh = currentStage.minStreak;
    const target = currentStage.nextThreshold;
    const currentSpan = Math.max(0, appState.streak - prevThresh);
    const totalSpan = target - prevThresh;
    const pct = Math.min(100, Math.round((currentSpan / totalSpan) * 100));

    if (ratioText) ratioText.textContent = `${appState.streak} / ${target} días de racha`;
    if (evoFill) evoFill.style.width = `${Math.max(10, pct)}%`;

    const nextStageObj = DRAGON_STAGES[currentStage.id + 1];
    if (evoHint && nextStageObj) {
      evoHint.innerHTML = `Siguiente forma: <strong>${nextStageObj.name}</strong> a los ${target} días.`;
    }
  } else {
    if (ratioText) ratioText.textContent = `${appState.streak} días (Forma Suprema)`;
    if (evoFill) evoFill.style.width = '100%';
    if (evoHint) evoHint.innerHTML = `🌟 <strong>¡Has despertado el poder cósmico definitivo!</strong>`;
  }

  // Galería de Etapas
  for (let i = 0; i < 4; i++) {
    const el = document.getElementById(`gallery-stage-${i}`);
    if (el) {
      if (i <= currentStage.id) {
        el.classList.add('active');
      } else {
        el.classList.remove('active');
      }
    }
  }

  // 4. Vista de Rachas
  renderStreakView();

  // 5. Tareas, Misiones, Tienda, Estadísticas
  renderTasks();
  renderQuests();
  renderShop();
  renderAchievements();
  renderAnalytics();
}

function renderStreakView() {
  const heroDays = document.getElementById('hero-streak-days');
  if (heroDays) heroDays.textContent = appState.streak;

  const bestRecord = document.getElementById('best-streak-record');
  if (bestRecord) bestRecord.textContent = appState.bestStreak;

  const totalMin = document.getElementById('total-minutes-studied');
  if (totalMin) totalMin.textContent = appState.totalMinutes;

  const totalSess = document.getElementById('total-sessions-completed');
  if (totalSess) totalSess.textContent = appState.totalSessions;

  const shieldsCount = document.getElementById('streak-freezes-count');
  if (shieldsCount) shieldsCount.textContent = appState.streakFreezes;

  // Barra de Meta fijada
  const goal = appState.goalDays;
  const curr = appState.streak;
  const pct = Math.min(100, Math.round((curr / goal) * 100));

  const goalFraction = document.getElementById('goal-progress-fraction');
  if (goalFraction) goalFraction.textContent = `${curr} / ${goal} días (${pct}%)`;

  const goalFill = document.getElementById('goal-meter-fill');
  if (goalFill) goalFill.style.width = `${pct}%`;

  const goalAdvice = document.getElementById('goal-advice-text');
  if (goalAdvice) {
    const rem = goal - curr;
    if (rem <= 0) {
      goalAdvice.innerHTML = `🎉 <strong>¡Meta de ${goal} días completada!</strong> Fija una meta superior para seguir creciendo.`;
    } else {
      goalAdvice.innerHTML = `Faltan <strong>${rem} días</strong> de estudio para conquistar tu objetivo de ${goal} días.`;
    }
  }

  document.querySelectorAll('.goal-card-btn').forEach(btn => {
    const g = parseInt(btn.getAttribute('data-goal'), 10);
    if (g === goal) btn.classList.add('active');
    else btn.classList.remove('active');
  });

  // Generar Calendario Mensual Completo
  renderMonthlyCalendar();
}

function renderMonthlyCalendar() {
  const container = document.getElementById('monthly-calendar-grid');
  if (!container) return;
  container.innerHTML = '';

  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const calMonthTitle = document.getElementById('calendar-month-title');
  if (calMonthTitle) calMonthTitle.textContent = `${monthNames[month]} ${year}`;

  // Encabezados Lun - Dom
  const daysHeader = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  daysHeader.forEach(d => {
    const el = document.createElement('div');
    el.className = 'calendar-day-head';
    el.textContent = d;
    container.appendChild(el);
  });

  // Primer día del mes y número de días
  const firstDay = new Date(year, month, 1).getDay(); // 0 Dom, 1 Lun...
  const totalDays = new Date(year, month + 1, 0).getDate();

  // Desplazamiento de lunes
  const offset = firstDay === 0 ? 6 : firstDay - 1;

  for (let i = 0; i < offset; i++) {
    const empty = document.createElement('div');
    empty.className = 'calendar-cell empty';
    container.appendChild(empty);
  }

  const todayIso = getTodayISO();

  for (let day = 1; day <= totalDays; day++) {
    const mStr = String(month + 1).padStart(2, '0');
    const dStr = String(day).padStart(2, '0');
    const isoDate = `${year}-${mStr}-${dStr}`;

    const cell = document.createElement('div');
    cell.className = 'calendar-cell';
    cell.textContent = day;

    if (isoDate === todayIso) cell.classList.add('today');
    if (appState.completedDates.includes(isoDate)) cell.classList.add('completed');

    container.appendChild(cell);
  }
}

// 5. Tareas
function renderTasks() {
  const container = document.getElementById('tasks-list-container');
  if (!container) return;
  container.innerHTML = '';

  if (appState.tasks.length === 0) {
    container.innerHTML = `<div style="text-align:center; color:var(--text-faint); padding:1rem; font-size:0.85rem;">No hay tareas para esta sesión. ¡Agrega una arriba!</div>`;
    return;
  }

  appState.tasks.forEach(task => {
    const item = document.createElement('div');
    item.className = `task-item-card ${task.completed ? 'completed' : ''}`;

    item.innerHTML = `
      <label class="task-checkbox-label">
        <input type="checkbox" ${task.completed ? 'checked' : ''} data-id="${task.id}">
        <span>${escapeHtml(task.text)}</span>
      </label>
      <button class="btn-delete-task" data-id="${task.id}" title="Eliminar tarea">✕</button>
    `;

    // Checkbox toggle
    item.querySelector('input').addEventListener('change', (e) => {
      task.completed = e.target.checked;
      if (task.completed) {
        audioSynth.playChimeTreasure();
        appState.dragonXp += 15;
        appState.dragonCoins += 5;
        appState.tasksCompletedCount = (appState.tasksCompletedCount || 0) + 1;
        showFloatingRPGText('+15 XP / +5 🪙', '#10b981', 160, 60);
        updateQuestProgress('task', 1);
        checkAchievements();
      }
      saveState();
      renderTasks();
      renderAllViews();
    });

    // Delete
    item.querySelector('.btn-delete-task').addEventListener('click', () => {
      appState.tasks = appState.tasks.filter(t => t.id !== task.id);
      saveState();
      renderTasks();
    });

    container.appendChild(item);
  });
}

// 6. Misiones Diarias
function renderQuests() {
  const container = document.getElementById('quests-list-container');
  if (!container) return;
  container.innerHTML = '';

  appState.dailyQuests.forEach(q => {
    const isCompleted = q.current >= q.target;
    const card = document.createElement('div');
    card.className = `quest-item-card ${isCompleted && !q.claimed ? 'claimable' : ''} ${q.claimed ? 'completed' : ''}`;

    card.innerHTML = `
      <div class="quest-info-block">
        <span class="quest-title-text">${q.title} (${q.current}/${q.target})</span>
        <span class="quest-reward-pill">🪙 +${q.rewardCoins} Monedas • ✨ +${q.rewardXp} XP</span>
      </div>
      <div>
        ${q.claimed
          ? `<span style="font-size:0.8rem; color:var(--magic-emerald); font-weight:700;">✓ Reclamado</span>`
          : (isCompleted
            ? `<button class="btn-claim-quest" data-id="${q.id}">¡Reclamar!</button>`
            : `<span style="font-size:0.75rem; color:var(--text-faint);">En progreso</span>`
          )
        }
      </div>
    `;

    const btnClaim = card.querySelector('.btn-claim-quest');
    if (btnClaim) {
      btnClaim.addEventListener('click', () => {
        q.claimed = true;
        appState.dragonCoins += q.rewardCoins;
        appState.dragonXp += q.rewardXp;
        audioSynth.playChimeTreasure();
        showFloatingRPGText(`+${q.rewardCoins} 🪙 / +${q.rewardXp} XP`, '#FFD700', 160, 80);
        checkDragonLevelUp();
        saveState();
        renderAllViews();
      });
    }

    container.appendChild(card);
  });
}

// 7. Tienda / Bazar
function renderShop() {
  const balanceEl = document.getElementById('shop-coins-balance');
  if (balanceEl) balanceEl.textContent = appState.dragonCoins;

  const container = document.getElementById('shop-items-container');
  if (!container) return;
  container.innerHTML = '';

  SHOP_CATALOG.forEach(item => {
    const isOwned = (item.type === 'aura' && appState.unlockedAuras.includes(item.id.replace('aura_', '')))
      || (item.type === 'habitat' && appState.unlockedHabitats.includes(item.id.replace('hab_', '')));

    const card = document.createElement('div');
    card.className = 'shop-item-card';

    card.innerHTML = `
      <div class="shop-item-top">
        <div class="shop-item-icon">${item.icon}</div>
        <div class="shop-item-details">
          <h4>${item.name}</h4>
          <p>${item.desc}</p>
        </div>
      </div>
      <button class="btn-buy-item ${isOwned ? 'owned' : ''}" ${isOwned ? 'disabled' : ''} data-id="${item.id}">
        ${isOwned ? '✓ Desbloqueado' : `<span>🪙 ${item.price}</span> Comprar`}
      </button>
    `;

    const btnBuy = card.querySelector('.btn-buy-item');
    if (btnBuy && !isOwned) {
      btnBuy.addEventListener('click', () => {
        if (appState.dragonCoins < item.price) {
          showFloatingRPGText('¡Monedas Insuficientes!', '#ef4444', 160, 60);
          return;
        }

        appState.dragonCoins -= item.price;
        audioSynth.playChimeTreasure();

        if (item.type === 'aura') {
          const auraKey = item.id.replace('aura_', '');
          appState.unlockedAuras.push(auraKey);
          appState.dragonAura = auraKey;
        } else if (item.type === 'habitat') {
          const habKey = item.id.replace('hab_', '');
          appState.unlockedHabitats.push(habKey);
          appState.dragonHabitat = habKey;
        } else if (item.id === 'item_freeze') {
          appState.streakFreezes += 1;
        }

        showFloatingRPGText(`¡${item.name} Adquirido! ✨`, '#10b981', 160, 80);
        saveState();
        renderAllViews();
      });
    }

    container.appendChild(card);
  });
}

// 8. Logros
function renderAchievements() {
  const container = document.getElementById('badges-showcase-grid');
  if (!container) return;
  container.innerHTML = '';

  ALL_ACHIEVEMENTS.forEach(ach => {
    const isUnlocked = appState.unlockedBadges.includes(ach.id);
    const card = document.createElement('div');
    card.className = `badge-card ${isUnlocked ? 'unlocked' : 'locked'}`;

    card.innerHTML = `
      <div class="badge-icon-box">${ach.icon}</div>
      <span class="badge-name-label">${ach.name}</span>
      <span class="badge-req-desc">${ach.criteria}</span>
    `;

    container.appendChild(card);
  });
}

// 9. Estadísticas y Gráfico Semanal
function renderAnalytics() {
  const totalMinEl = document.getElementById('analytics-total-minutes');
  if (totalMinEl) totalMinEl.textContent = `${appState.totalMinutes} min`;

  const totalSessEl = document.getElementById('analytics-total-sessions');
  if (totalSessEl) totalSessEl.textContent = appState.totalSessions;

  const totalCoinsEl = document.getElementById('analytics-total-coins');
  if (totalCoinsEl) totalCoinsEl.textContent = appState.dragonCoins;

  // Gráfico de Barras Semanal
  const chartContainer = document.getElementById('weekly-chart-wrapper');
  if (chartContainer) {
    chartContainer.innerHTML = '';
    const dayNames = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

    // Simular o calcular distribución de los últimos 7 días
    dayNames.forEach((dName, idx) => {
      const col = document.createElement('div');
      col.className = 'chart-bar-column';

      // Altura basada en minutos de estudio o proporcional
      const heightPercent = Math.min(100, Math.max(12, (appState.totalMinutes / (idx + 1)) % 100));

      col.innerHTML = `
        <div class="chart-bar-fill" style="height: ${heightPercent}%;"></div>
        <span class="chart-bar-label">${dName}</span>
      `;
      chartContainer.appendChild(col);
    });
  }

  // Tabla de Historial
  const tbody = document.getElementById('history-table-body');
  if (tbody) {
    tbody.innerHTML = '';
    if (appState.sessionLogs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-faint); padding:1.5rem;">Aún no hay sesiones registradas. ¡Inicia una sesión de estudio para comenzar tu historial!</td></tr>`;
      return;
    }

    appState.sessionLogs.slice(0, 10).forEach(log => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${escapeHtml(log.date)}</td>
        <td><strong>${log.duration} min</strong></td>
        <td><span class="tag-pill">${escapeHtml(log.subject || 'General')}</span></td>
        <td style="color:var(--accent-gold);">+${log.coinsEarned} 🪙 / +${log.xpEarned} XP</td>
      `;
      tbody.appendChild(tr);
    });
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// ==========================================
// 9. CINEMÁTICAS & MODALES
// ==========================================

function showCompletionModal(studiedMinutes, coins, xp, streakResult) {
  const modal = document.getElementById('completion-modal');
  if (!modal) return;

  const streakPill = document.getElementById('modal-streak-reward-pill');
  if (streakPill) {
    streakPill.textContent = streakResult.streakIncreased
      ? `🔥 ¡Racha Aumentada a ${streakResult.newStreak} días! (+${coins} 🪙 / +${xp} XP)`
      : `✨ ¡Gran Sesión de ${studiedMinutes} min! (+${coins} 🪙 / +${xp} XP)`;
  }

  const speech = document.getElementById('modal-dragon-speech');
  if (speech) {
    speech.textContent = `"¡Increíble trabajo! Tu disciplina forja el poder de nuestra mente. Sigue así y conquistaremos cualquier objetivo."`;
  }

  const evoAlert = document.getElementById('modal-evolution-alert');
  const evoName = document.getElementById('modal-new-stage-name');
  if (streakResult.evolved && evoAlert && evoName) {
    evoAlert.style.display = 'block';
    evoName.textContent = `¡Tu dragón ha evolucionado a: ${streakResult.newStage.name}!`;
    audioSynth.playDragonAction(streakResult.newStage.id);
  } else if (evoAlert) {
    evoAlert.style.display = 'none';
  }

  modal.classList.add('active');
  launchConfetti();
}

function launchConfetti() {
  const canvas = document.getElementById('modal-confetti-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = canvas.parentElement.clientWidth || 400;
  canvas.height = canvas.parentElement.clientHeight || 450;

  const particles = [];
  const colors = ['#FF7A00', '#FF3D00', '#FFEB3B', '#6366F1', '#10B981', '#EC4899', '#38BDF8'];

  for (let i = 0; i < 80; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 14,
      vy: (Math.random() - 0.7) * 16,
      size: Math.random() * 7 + 3,
      color: colors[Math.floor(Math.random() * colors.length)],
      gravity: 0.35,
      alpha: 1,
      rotation: Math.random() * 360
    });
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;

    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += p.gravity;
      p.alpha -= 0.012;
      p.rotation += 5;

      if (p.alpha > 0) {
        alive = true;
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    });

    if (alive) {
      requestAnimationFrame(animate);
    }
  }
  animate();
}

// Textos flotantes RPG
function showFloatingRPGText(text, color = '#FFD700', x = 160, y = 100) {
  const container = document.getElementById('floating-rpg-container');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'rpg-float-text';
  el.textContent = text;
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  el.style.color = color;
  container.appendChild(el);
  setTimeout(() => {
    if (el.parentNode) el.parentNode.removeChild(el);
  }, 1300);
}

// Partículas de Fondo Estelares
function initBackgroundParticles() {
  const canvas = document.getElementById('particles-bg');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  const embers = [];
  for (let i = 0; i < 45; i++) {
    embers.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 1.8 + 0.6,
      speedY: Math.random() * 0.45 + 0.15,
      alpha: Math.random() * 0.6 + 0.2
    });
  }

  function renderEmbers() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FF9800';

    embers.forEach(s => {
      s.y -= s.speedY;
      if (s.y < 0) {
        s.y = canvas.height;
        s.x = Math.random() * canvas.width;
      }
      ctx.globalAlpha = s.alpha;
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
      ctx.fill();
    });

    requestAnimationFrame(renderEmbers);
  }
  renderEmbers();
}

// ==========================================
// 10. INICIALIZACIÓN Y EVENT LISTENERS
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initBackgroundParticles();

  // 1. Selector de Pestañas Principales
  const tabButtons = document.querySelectorAll('.nav-tab-btn');
  const viewPanels = document.querySelectorAll('.view-panel');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      audioSynth.playClick();
      const targetId = btn.getAttribute('data-target');

      tabButtons.forEach(b => b.classList.remove('active'));
      viewPanels.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPanel = document.getElementById(targetId);
      if (targetPanel) {
        targetPanel.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  });

  // Acceso directo a Santuario desde el Banner
  const miniBanner = document.getElementById('mini-dragon-study-banner');
  if (miniBanner) {
    miniBanner.addEventListener('click', () => {
      const dragonTab = document.querySelector('.nav-tab-btn[data-target="view-dragon"]');
      if (dragonTab) dragonTab.click();
    });
  }

  // Clic en el logo para volver a Estudio
  const brandTrigger = document.getElementById('brand-home-trigger');
  if (brandTrigger) {
    brandTrigger.addEventListener('click', () => {
      const studyTab = document.querySelector('.nav-tab-btn[data-target="view-study"]');
      if (studyTab) studyTab.click();
    });
  }

  // 2. Modos del Temporizador (Pomodoro 25, Deep Work 50, etc.)
  document.querySelectorAll('.mode-pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (studyTimer.isRunning) return;
      audioSynth.playClick();
      document.querySelectorAll('.mode-pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const mode = btn.getAttribute('data-mode');
      appState.timerMode = mode;

      let mins = 25;
      if (mode === 'pomodoro') mins = 25;
      else if (mode === 'deepwork') mins = 50;
      else if (mode === 'quick') mins = 15;
      else if (mode === 'ultra') mins = 90;
      else if (mode === 'shortbreak') {
        mins = 5;
        studyTimer.isBreak = true;
      }

      studyTimer.setDuration(mins);

      const sessLabel = document.getElementById('timer-session-label');
      if (sessLabel) sessLabel.textContent = studyTimer.isBreak ? "Descanso" : "Enfoque";
    });
  });

  // Chips de duración rápida
  document.querySelectorAll('.duration-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      if (studyTimer.isRunning) return;
      audioSynth.playClick();
      document.querySelectorAll('.duration-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      const mins = parseInt(chip.getAttribute('data-mins'), 10);
      studyTimer.setDuration(mins);
    });
  });

  // Botones del Temporizador
  const btnStart = document.getElementById('btn-start-timer');
  const btnPause = document.getElementById('btn-pause-timer');
  const btnReset = document.getElementById('btn-reset-timer');

  if (btnStart) btnStart.addEventListener('click', () => studyTimer.start());
  if (btnPause) {
    btnPause.addEventListener('click', () => {
      if (studyTimer.isPaused) studyTimer.resume();
      else studyTimer.pause();
    });
  }
  if (btnReset) btnReset.addEventListener('click', () => studyTimer.reset());

  // Modo Enfoque Total Pantalla Completa
  const btnFullscreenFocus = document.getElementById('btn-fullscreen-focus');
  const focusBackdrop = document.getElementById('focus-mode-backdrop');
  const btnExitFocus = document.getElementById('btn-exit-focus');

  if (btnFullscreenFocus && focusBackdrop) {
    btnFullscreenFocus.addEventListener('click', () => {
      focusBackdrop.classList.add('active');
      audioSynth.playClick();
    });
  }
  if (btnExitFocus && focusBackdrop) {
    btnExitFocus.addEventListener('click', () => {
      focusBackdrop.classList.remove('active');
      audioSynth.playClick();
    });
  }

  // Selector de Materia
  document.querySelectorAll('.subject-badge-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      audioSynth.playClick();
      document.querySelectorAll('.subject-badge-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      appState.selectedSubject = pill.getAttribute('data-subject');
      const tag = document.getElementById('timer-subject-tag');
      if (tag) tag.textContent = appState.selectedSubject;
      saveState();
    });
  });

  // Agregar Tarea
  const btnAddTask = document.getElementById('btn-add-task');
  const inputTask = document.getElementById('input-new-task');

  function addNewTask() {
    if (!inputTask) return;
    const text = inputTask.value.trim();
    if (!text) return;

    appState.tasks.push({
      id: 't_' + Date.now(),
      text,
      completed: false,
      subject: appState.selectedSubject
    });
    inputTask.value = '';
    audioSynth.playClick();
    saveState();
    renderTasks();
  }

  if (btnAddTask) btnAddTask.addEventListener('click', addNewTask);
  if (inputTask) {
    inputTask.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') addNewTask();
    });
  }

  // Sonidos Ambientales
  document.querySelectorAll('.sound-chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      audioSynth.playClick();
      document.querySelectorAll('.sound-chip-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const soundType = btn.getAttribute('data-sound');
      audioSynth.setAmbient(soundType);
    });
  });

  // Selector de Metas de Racha (7, 21, 30, 60 días)
  document.querySelectorAll('.goal-card-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      audioSynth.playClick();
      const goal = parseInt(btn.getAttribute('data-goal'), 10);
      appState.goalDays = goal;
      saveState();
      renderStreakView();
    });
  });

  // 3. INTERACCIONES DEL SANTUARIO DEL DRAGÓN
  const heroSlot = document.getElementById('dragon-hero-svg-slot');
  const bubbleText = document.getElementById('bubble-text');
  const fireCone = document.getElementById('fire-breath-cone');

  function setDragonDialogue(phrase) {
    if (bubbleText) bubbleText.textContent = phrase;
    const miniQuote = document.getElementById('dragon-quote');
    if (miniQuote) miniQuote.textContent = `"${phrase}"`;
  }

  function wiggleHeroDragon() {
    if (heroSlot) {
      heroSlot.classList.remove('dragon-wiggle');
      void heroSlot.offsetWidth;
      heroSlot.classList.add('dragon-wiggle');
    }
  }

  // Acción: Acariciar
  function petDragon() {
    const stage = getDragonStageByStreak(appState.streak);
    audioSynth.playDragonAction(stage.id);
    wiggleHeroDragon();

    appState.dragonBond = Math.min(100, appState.dragonBond + 8);
    updateQuestProgress('pet', 1);
    saveState();
    renderAllViews();

    const phrases = [
      "¡Purrr! Me encanta cuando me acaricias y cuidamos nuestro hábito.",
      "¡Siento cómo crece nuestro vínculo! Cada día somos más fuertes.",
      "Tus mimos alimentan mi llama protectora de estudio."
    ];
    setDragonDialogue(phrases[Math.floor(Math.random() * phrases.length)]);
    showFloatingRPGText('+8 ❤️ Vínculo', '#EC4899', 160, 110);
  }

  const btnPet = document.getElementById('btn-pet-dragon');
  if (btnPet) btnPet.addEventListener('click', petDragon);
  if (heroSlot) heroSlot.addEventListener('click', petDragon);

  // Acción: Alimentar
  const btnFeed = document.getElementById('btn-feed-dragon');
  if (btnFeed) {
    btnFeed.addEventListener('click', () => {
      audioSynth.playClick();
      wiggleHeroDragon();

      appState.dragonEnergy = Math.min(100, appState.dragonEnergy + 15);
      appState.dragonBond = Math.min(100, appState.dragonBond + 4);
      saveState();
      renderAllViews();

      setDragonDialogue("¡Delicioso banquete ígneo! Mis alas están llenas de vigor.");
      showFloatingRPGText('+15 ⚡ Energía', '#FF7A00', 160, 110);
    });
  }

  // Acción: Sabiduría / Pergamino
  const btnScroll = document.getElementById('btn-scroll-dragon');
  if (btnScroll) {
    btnScroll.addEventListener('click', () => {
      audioSynth.playChimeTreasure();
      wiggleHeroDragon();

      const studyTips = [
        "Técnica Feynman: Explica el tema en tus propias palabras a tu dragón.",
        "Repetición Espaciada: Revisa tus notas hoy, en 3 días y en 1 semana.",
        "Monotarea: Enfocar tu atención al 100% rinde 3 veces más que estudiar con distracciones.",
        "Descansos de 5 min: Deja reposar la mente para que la memoria a largo plazo consolide lo aprendido."
      ];
      setDragonDialogue(studyTips[Math.floor(Math.random() * studyTips.length)]);
      showFloatingRPGText('+5 📜 Sabiduría', '#6366f1', 160, 90);
    });
  }

  // Acción: Rugido Épico
  const btnRoar = document.getElementById('btn-roar-dragon');
  if (btnRoar) {
    btnRoar.addEventListener('click', () => {
      audioSynth.playRoarBreath();
      wiggleHeroDragon();

      if (fireCone) {
        fireCone.classList.add('active');
        setTimeout(() => fireCone.classList.remove('active'), 1200);
      }

      setDragonDialogue("¡¡ROAAAR!! ¡El fuego de la perseverancia consume la pereza!");
      showFloatingRPGText('¡LLAMARADA FEROZ! 🔥', '#ef4444', 160, 90);
    });
  }

  // Cofre de Tesoro del Hábitat
  const treasureChest = document.getElementById('dragon-treasure-chest');
  if (treasureChest) {
    treasureChest.addEventListener('click', () => {
      audioSynth.playChimeTreasure();
      wiggleHeroDragon();

      const reward = 25;
      appState.dragonCoins += reward;
      appState.dragonBond = Math.min(100, appState.dragonBond + 6);
      saveState();
      renderAllViews();

      showFloatingRPGText(`¡Tesoro Sagrado! +${reward} 🪙`, '#FFD700', 200, 140);
      setDragonDialogue("¡Has reclamado las gemas del santuario! Tu constancia da frutos.");
    });
  }

  // Selector de Auras
  document.querySelectorAll('.aura-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const aura = btn.getAttribute('data-aura');
      if (!appState.unlockedAuras.includes(aura)) {
        showFloatingRPGText('¡Aura Bloqueada! Consíguela en el Bazar', '#ef4444', 160, 60);
        return;
      }
      audioSynth.playClick();
      appState.dragonAura = aura;
      saveState();
      renderAllViews();
      showFloatingRPGText(`Aura Sintonizada ✨`, '#38bdf8', 160, 60);
    });
  });

  // Cerrar Modal de Celebración
  const btnCloseModal = document.getElementById('btn-close-modal');
  if (btnCloseModal) {
    btnCloseModal.addEventListener('click', () => {
      document.getElementById('completion-modal').classList.remove('active');
      audioSynth.playClick();
    });
  }

  // Header Icon Buttons (Mute / Theme)
  const btnToggleMute = document.getElementById('btn-toggle-mute');
  if (btnToggleMute) {
    btnToggleMute.addEventListener('click', () => {
      const enabled = audioSynth.toggleSound();
      btnToggleMute.textContent = enabled ? '🔊' : '🔇';
      showFloatingRPGText(enabled ? 'Sonido Activado 🔊' : 'Sonido Silenciado 🔇', '#94a3b8', 160, 40);
    });
  }

  const btnToggleTheme = document.getElementById('btn-toggle-theme');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      const themes = ['default', 'astral', 'cyberpunk', 'light'];
      const currentIndex = themes.indexOf(appState.theme || 'default');
      const nextTheme = themes[(currentIndex + 1) % themes.length];
      appState.theme = nextTheme;
      applyTheme(nextTheme);
      saveState();
      audioSynth.playClick();
    });
  }

  function applyTheme(themeName) {
    document.body.className = '';
    if (themeName !== 'default') {
      document.body.classList.add(`theme-${themeName}`);
    }
  }
  applyTheme(appState.theme);

  // Selector de Tema en Ajustes
  const selectTheme = document.getElementById('select-app-theme');
  if (selectTheme) {
    selectTheme.value = appState.theme || 'default';
    selectTheme.addEventListener('change', (e) => {
      appState.theme = e.target.value;
      applyTheme(appState.theme);
      saveState();
    });
  }

  // Exportar / Importar Datos
  const btnExportData = document.getElementById('btn-export-data');
  if (btnExportData) {
    btnExportData.addEventListener('click', () => {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appState, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `studyBuddy_backup_${getTodayISO()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    });
  }

  const btnResetAll = document.getElementById('btn-reset-data');
  if (btnResetAll) {
    btnResetAll.addEventListener('click', () => {
      if (confirm('¿Seguro que deseas reiniciar todos los progresos de studyBuddy?')) {
        localStorage.removeItem('studyBuddy_pro_v2_state');
        appState = { ...DEFAULT_STATE };
        saveState();
        studyTimer.reset();
        renderAllViews();
        alert('Datos reiniciados con éxito.');
      }
    });
  }

  // Registro opcional de Service Worker para soporte Offline
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    });
  }

  // Render inicial de todo el ecosistema
  renderAllViews();
  studyTimer.setDuration(25);
});
